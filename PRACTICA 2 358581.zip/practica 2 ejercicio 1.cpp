
#include <stdio.h>
#include <iostream>

int main(){

int numero;
printf("dime un numero");
scanf("%d",&numero);

if(numero%2==0)
{
printf("Es par");
}
else
{
printf("Es impar");
}


}



