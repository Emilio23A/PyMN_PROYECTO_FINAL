
#include <stdio.h>



int main()
{
    int edad;
    printf("edad:");
    scanf("%d",&edad);
    if(edad>=18)
    {printf("es mayor de edad");
    }else
    {printf("es menor de edad");
    }
    

  
}
