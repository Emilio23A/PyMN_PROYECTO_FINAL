
#include <stdio.h>
#include <iostream>
int main()
{
  int estCivil, sueldo;
  printf("si usted es casado, ingrese 1");
  printf("\n si usted es soltero, ingrese 2");
  printf("\n ingrese su estado civil");
  scanf("%d",&estCivil);
  printf(" ingrese su sueldo mensual");
  scanf("%d",&sueldo);
  
 if(estCivil==1){
 if(sueldo<64000){
printf("\n su tasa de impuestos es del 10 porciento");
 }
 }
 if(estCivil==1){
 if (sueldo>64000){
printf("\n su tasa de impuestos es del 25 porciento");
}
}
if(estCivil==2){  
if(sueldo<32000){
    printf("\n su tasa de impuestos es del 10 porciento");
}
}
if(estCivil==2){
if(sueldo>32000){
printf("\n su tasa de impuestos es del 25 porciento");
}
}
}


