
#include <stdio.h>

int main()
{
    int departamento;
    char bolsas, si, no;
    printf("los departamentos son: perfumeria,salchichoneria,carniceria y limpieza");
    printf("\n para escoger algun departamento ingrese un numero del 1 al 4 respectivamente");
    printf("\n en que area departamental quiere ingresar");
    scanf("%d",&departamento);
    printf("¿llevara bolsas?");
    scanf("%s",&bolsas);
    
    if(departamento==1 && bolsas==si){
        printf("\n Hay descuento del 20 porciento, se le cobrara 10 centavos por bolsa");
    }
    if(departamento==1 && bolsas==no){
    printf("\n Hay descuento del 20 porciento");
}
if(departamento==2 && bolsas==si){
    printf("\n Hay descuento del 40 porciento, se le cobrara 10 centavos por bolsa");
    }
    if(departamento==2 && bolsas==no){
    printf("\n Hay descuento del 40 porciento");
}
if(departamento==3 && bolsas==si){
    printf("\n Hay descuento del 20 porciento, se le cobrara 10 centavos por bolsa");
}
if(departamento==3 && bolsas==no){
    printf("\n Hay descuento del 40 porciento");
}
if(departamento==4 && bolsas==si){
    printf("\n Hay descuento del 35 porciento, se le cobrara 10 centavos por bolsa");
}
if(departamento==4 && bolsas==no){
    printf("\n Hay descuento del 35 porciento");
}
}