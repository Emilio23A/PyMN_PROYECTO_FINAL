
#include <stdio.h>
#include <math.h>
int main()
{
    float peso,estatura;
    printf("ingrese su peso y estatura");
    scanf("%f%f",&peso,&estatura);
    
    float IMC = peso/(pow(estatura,2));
    
    if(IMC<18.5){
        printf("su clasificacion es peso bajo");
    }
    if(18.5<=IMC<=24.9){
        printf("su clasificacion es peso normal");  
    }
     if(25<=IMC<=29.9){
          printf("su clasificacion es sobrepeso");
}
 if(30<=IMC<=34.5){
      printf("su clasificacion es obesidad tipo 1");
 }
 if(35<=IMC<=39.9){
  printf("su clasificacion es obesidad tipo 2");
 }
 if(IMC>40){
 printf("su clasificacion es hiper obesidad ");
 }
}