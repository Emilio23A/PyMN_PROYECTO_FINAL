
#include <stdio.h>
#include <math.h>


int main ()
{
    float a, b, c, r1, r2, r3, r4, r5;
  scanf ("%f", &a);
  scanf ("%f", &b);
  scanf ("%f", &c);
  if (a != 0)
    {
      r3 = pow (b, 2);
      r4 = (4 * a * c);
      r5 = (r3 - r4);
      if (r5 < 0)
	{
	  printf("ERROR");
	}
      if (r5 >= 0)
	{
	  r1=((-b+(sqrt(r5)))/(2*a));
      r2=((-b-(sqrt(r5)))/(2*a));
      if(r1==r2)
      {
          printf("\n El resultado es %.2f",r1);
      }
      if(r1!=r2)
      {
          printf("\n El resultado de x1 es %.2f",r1);
          printf("\n El resultado de x2 es %.2f",r2);
      }
	}
    }
}
